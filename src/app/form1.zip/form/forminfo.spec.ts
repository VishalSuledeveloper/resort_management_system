import { Forminfo } from './forminfo';

describe('Forminfo', () => {
  it('should create an instance', () => {
    expect(new Forminfo()).toBeTruthy();
  });
});
