export class Forminfo {
    Name!: string;
    Email!: string;
    PhoneNumber!: string;
    Address!: string;
    Rooms!: string;
    Foods!: string;
    DiveSite!: string;
}
