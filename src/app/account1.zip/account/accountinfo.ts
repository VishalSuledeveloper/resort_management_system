export class Accountinfo {
     Name!: string; 
     Email!: string; 
     Subject!: string; 
     Message!: string;
}