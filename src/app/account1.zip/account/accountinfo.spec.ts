import { Accountinfo } from './accountinfo';

describe('Accountinfo', () => {
  it('should create an instance', () => {
    expect(new Accountinfo()).toBeTruthy();
  });
});
